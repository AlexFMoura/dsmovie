package com.alex.dsmove;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DsmoveApplication {

	public static void main(String[] args) {
		SpringApplication.run(DsmoveApplication.class, args);
	}

}
