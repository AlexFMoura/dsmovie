package com.alex.dsmove;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DsmoveApplicationTests {

	@Test
	void contextLoads() {
	}

}
